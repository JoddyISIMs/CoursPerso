$(document).ready(function(){	/* Ouverture image, boutons cotés et flèche */
	$("a.ImageGrande").fancybox({
		openEffect : 'elastic',
		closeEffect : 'elastic', 
		'speedIn': 400,
		'speedOut': 400
	});

	$("#BoutonVersHaut").css("display", "none");			
		$(window).scroll(function(){
			if($(window).scrollTop() > 100){
			console.log("is more");
			$("#BoutonVersHaut").fadeIn("slow");
			}
			else {
			console.log("is less");
			$("#BoutonVersHaut").fadeOut("slow");
		}
	});

	$("#BoutonVersHaut").click(function(){
		event.preventDefault();
		$("html, body").animate({scrollTop:0},{duration:500});
	});

	$("#BoutonMilieu").click(function(){
		event.preventDefault();
		$("html, body").animate({scrollTop:770},{duration:600});
	});

	$("#BoutonXP").click(function(){
		event.preventDefault();
		$("html, body").animate({scrollTop:1185},{duration:700});
	});

	$("#BoutonComp").click(function(){
		event.preventDefault();
		$("html, body").animate({scrollTop:1655},{duration:700});
	});

	$("#BoutonAdd").click(function(){
		event.preventDefault();
		$("html, body").animate({scrollTop:2380},{duration:700});
	});
});	

function ouverture(){	/* Ouverture et fermeture par clic */
	if($("#zone").width() == 15){
		$("#zone").animate({width:300},{duration:600});
		$(".Dedans").stop(true,true).fadeIn();
	}
	if($("#zone").width() == 300){
		$("#zone").animate({width:15},{duration:600});
		$(".Dedans").stop(true,true).fadeOut();
	}		
}

function ouvertureAuto(){	/* Ouverture auto #zone et photo de profil */
	$("#zone").animate({width:300},{duration:600});
	$(".Dedans").stop(true,true).fadeIn();
}
setTimeout(ouvertureAuto, 1500);

function scrollMove(ev){	/* Animations des barres diverses */
	if(window.pageYOffset>700){
		$("#hr").animate({width:750},{duration:800});
	}
	if(window.pageYOffset>1100){
		$("#hr2").animate({width:800},{duration:500});
	}
	if(window.pageYOffset>1550){ //Barre
		$("#barre").animate({width:640},{duration:850});
	}
	if(window.pageYOffset>1650){ //Barre
		$("#barreCSS").animate({width:600},{duration:850});
	}
	if(window.pageYOffset>1700){ //Barre
		$("#barreJS").animate({width:560},{duration:850});
	}	
	if(window.pageYOffset>1750){ //Barre
		$("#barreAndro").animate({width:560},{duration:850});
	}
	if(window.pageYOffset>1800){ //Barre
		$("#barre2").animate({width:560},{duration:850});
	}
	if(window.pageYOffset>1850){ //Barre
		$("#barre4").animate({width:560},{duration:850});
	}
	if(window.pageYOffset>1900){ //Barre
		$("#barre5").animate({width:720},{duration:850});
	}
	if(window.pageYOffset>1950){ //Barre
		$("#barre6").animate({width:720},{duration:850});
	}	
	if(window.pageYOffset>2000){ //Barre
		$("#barre7").animate({width:680},{duration:850});
	}		
}
window.onscroll=scrollMove


function color(){ /* Changement couleur cercle profil */
	document.getElementById("zone").style.background = "#005BBB";
 }

 function color2(){
	document.getElementById("zone").style.background = "#09D2B7";
 }

 function color3(){
 	document.getElementById("zone").style.background = "#E54D26";
 }

 function color4(){
 	document.getElementById("zone").style.background = "#808080";
 }