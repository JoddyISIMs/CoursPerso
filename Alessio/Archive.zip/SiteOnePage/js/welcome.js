function bienvenue(){	/* Message BIENVENUE */
	$("#hello").stop(true,true).fadeIn();
}
setTimeout(bienvenue, 1000);

function message2(){	/* Message NOM */
	$("#hello2").stop(true,true).fadeIn();
}
setTimeout(message2, 2500);

function message3(){	/* Message TRUCS QUE J'AIME */
	$("#hello3").stop(true,true).fadeIn();
}
setTimeout(message3, 5000);

function clear1(){ /* EFFACER PARTIE 1 */
	$("#hello").stop(true,true).fadeOut();
	$("#hello2").stop(true,true).fadeOut();
	$("#hello3").stop(true,true).fadeOut();
}
setTimeout(clear1, 11000);

/*--------------------------------------*/

function second(){	/* Message OBJECTIF */
	$("#second").stop(true,true).fadeIn();
}
setTimeout(second, 12000);

function second2(){	/* Message OBJECTIF 2 */
	$("#second2").stop(true,true).fadeIn();
}
setTimeout(second2, 13500);

function second3(){	/* Message OBJECTIF 3 */
	$("#second3").stop(true,true).fadeIn();
}
setTimeout(second3, 16000);

function clear2(){ /* EFFACER PARTIE 2 */
	$("#second").stop(true,true).fadeOut();
	$("#second2").stop(true,true).fadeOut();
	$("#second3").stop(true,true).fadeOut();
}
setTimeout(clear2, 24000);

/*--------------------------------------*/

function fin(){	/* Message FIN */
	$("#fin").stop(true,true).fadeIn();
}
setTimeout(fin, 25000);

function fin2(){	/* Message FIN 2 */
	$("#fin2").stop(true,true).fadeIn();
}
setTimeout(fin2, 26500);

function fin3(){	/* Message FIN 3 */
	$("#fin3").stop(true,true).fadeIn();
}
setTimeout(fin3, 32000);

function clear3(){ /* EFFACER PARTIE 3 */
	$("#fin").stop(true,true).fadeOut();
	$("#fin2").stop(true,true).fadeOut();
	$("#fin3").stop(true,true).fadeOut();
}
setTimeout(clear3, 33500);

window.setTimeout("location=('main.html');",34000);
